const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const COMPLAINTS_KEY = "sc_complaints";
const ENQUIRIES_KEY = "sc_enquiries";
const SERVICES_KEY = "sc_admin_services";
const LOGIN_KEY = "sc_admin_logged_in";

const defaultServices = [
  { id: "default-1", name: "Water Supply", category: "Utilities", description: "Report water supply interruptions and request assistance." },
  { id: "default-2", name: "Waste Collection", category: "Environment", description: "Information about waste pickup and public cleanliness." },
  { id: "default-3", name: "Public Transport", category: "Transport", description: "Find city transport information and route guidance." },
  { id: "default-4", name: "Street Lighting", category: "Public Safety", description: "Report damaged or non-working street lights." }
];

function readStore(key, fallback = []) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "null");
    return Array.isArray(value) ? value : fallback;
  } catch {
    return fallback;
  }
}
function writeStore(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}
function firstValue(item, keys, fallback = "—") {
  for (const key of keys) {
    if (item && item[key] !== undefined && item[key] !== null && String(item[key]).trim() !== "") return item[key];
  }
  return fallback;
}
function getComplaintName(item) {
  return firstValue(item, ["name", "fullName", "citizenName", "userName", "username"], "Citizen");
}
function getComplaintTitle(item) {
  return firstValue(item, ["subject", "title", "issue", "description", "message"], "Citizen complaint");
}
function getComplaintCategory(item) {
  return firstValue(item, ["category", "type", "department"], "General");
}
function getDate(item) {
  const raw = firstValue(item, ["date", "createdAt", "submittedAt", "timestamp"], "");
  if (!raw) return "—";
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? String(raw) : date.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function getStatus(item) {
  const value = String(firstValue(item, ["status", "state"], "Pending")).toLowerCase();
  return value === "submitted" ? "pending" : value;
}
function statusBadge(status) {
  const normalized = String(status || "pending").toLowerCase();
  const className = normalized === "in progress" || normalized === "in-progress" ? "badge-in-progress" :
    normalized === "resolved" ? "badge-resolved" : normalized === "pending" ? "badge-pending" : "badge-other";
  const label = normalized === "in-progress" ? "In Progress" : normalized.replace(/\b\w/g, c => c.toUpperCase());
  return `<span class="badge ${className}">${escapeHTML(label)}</span>`;
}
function getComplaints() { return readStore(COMPLAINTS_KEY); }
function getEnquiries() { return readStore(ENQUIRIES_KEY); }
function getServices() {
  const stored = readStore(SERVICES_KEY, null);
  if (stored.length) return stored;
  if (localStorage.getItem(SERVICES_KEY) === null) {
    writeStore(SERVICES_KEY, defaultServices);
    return [...defaultServices];
  }
  return [];
}

function showPage(page) {
  $$(".page").forEach(section => section.classList.add("hidden"));
  const target = $(`#page-${page}`);
  if (target) target.classList.remove("hidden");
  $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  const titles = { dashboard: "Dashboard", complaints: "Complaint Management", services: "Services Management", enquiries: "Enquiries Management" };
  $("#page-heading").textContent = titles[page] || "Dashboard";
  if (page === "dashboard") renderDashboard();
  if (page === "complaints") renderComplaints();
  if (page === "services") renderServices();
  if (page === "enquiries") renderEnquiries();
}
function openApp() {
  $("#login-screen").classList.add("hidden");
  $("#admin-app").classList.remove("hidden");
  $("#today-date").textContent = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  $("#footer-year").textContent = new Date().getFullYear();
  renderDashboard();
}
function renderDashboard() {
  const complaints = getComplaints();
  const enquiries = getEnquiries();
  const pending = complaints.filter(c => getStatus(c) === "pending").length;
  const resolved = complaints.filter(c => getStatus(c) === "resolved").length;
  $("#stat-total").textContent = complaints.length;
  $("#stat-pending").textContent = pending;
  $("#stat-resolved").textContent = resolved;
  $("#stat-enquiries").textContent = enquiries.length;
  $("#nav-pending").textContent = pending;
  const recent = complaints.slice().reverse().slice(0, 5);
  $("#recent-complaints").innerHTML = recent.map((c, index) => {
    const id = firstValue(c, ["id", "complaintId", "ticketId"], `SC-${String(index + 1).padStart(3, "0")}`);
    return `<tr><td><strong>${escapeHTML(id)}</strong><br><span>${escapeHTML(getComplaintName(c))}</span></td><td>${escapeHTML(getComplaintCategory(c))}</td><td>${escapeHTML(getDate(c))}</td><td>${statusBadge(getStatus(c))}</td></tr>`;
  }).join("");
  $("#recent-empty").classList.toggle("hidden", recent.length > 0);
}
function renderComplaints() {
  const search = ($("#complaint-search").value || "").toLowerCase().trim();
  const filter = $("#complaint-filter").value;
  const complaints = getComplaints().map((item, index) => ({ ...item, __index: index }));
  const filtered = complaints.filter(c => {
    const haystack = [firstValue(c, ["id", "complaintId", "ticketId"], ""), getComplaintName(c), getComplaintCategory(c), getComplaintTitle(c), getStatus(c)].join(" ").toLowerCase();
    const status = getStatus(c);
    return haystack.includes(search) && (filter === "all" || status === filter);
  });
  $("#complaints-table").innerHTML = filtered.map(c => {
    const id = firstValue(c, ["id", "complaintId", "ticketId"], `SC-${String(c.__index + 1).padStart(3, "0")}`);
    const status = getStatus(c);
    const issue = getComplaintTitle(c);
    return `<tr>
      <td><strong>${escapeHTML(id)}</strong><br><span>${escapeHTML(getComplaintName(c))}</span></td>
      <td>${escapeHTML(getComplaintCategory(c))}</td>
      <td title="${escapeHTML(issue)}">${escapeHTML(String(issue).length > 48 ? String(issue).slice(0, 48) + "…" : issue)}</td>
      <td>${escapeHTML(getDate(c))}</td>
      <td>${c.photo ? `<a class="photo-link" href="${c.photo}" target="_blank" rel="noopener"><img class="complaint-thumb" src="${c.photo}" alt="Complaint attachment"> View photo</a>` : "—"}</td>
      <td>${statusBadge(status)}</td>
      <td><select class="status-select" data-complaint-index="${c.__index}" aria-label="Update complaint status">
        <option value="Pending" ${status === "pending" ? "selected" : ""}>Pending</option>
        <option value="In Progress" ${status === "in progress" || status === "in-progress" ? "selected" : ""}>In Progress</option>
        <option value="Resolved" ${status === "resolved" ? "selected" : ""}>Resolved</option>
      </select></td>
    </tr>`;
  }).join("");
  $("#complaints-empty").classList.toggle("hidden", filtered.length > 0);
}
function renderServices() {
  const services = getServices();
  $("#service-count").textContent = services.length;
  $("#service-list").innerHTML = services.map((service, index) => `<article class="service-item">
    <div class="service-symbol">◇</div><div class="service-info"><strong>${escapeHTML(service.name)}</strong><p>${escapeHTML(service.description)}</p><small>${escapeHTML(service.category)}</small></div>
    <button class="delete-btn" data-delete-service="${index}">Delete</button>
  </article>`).join("");
  $("#services-empty").classList.toggle("hidden", services.length > 0);
}
function renderEnquiries() {
  const search = ($("#enquiry-search").value || "").toLowerCase().trim();
  const enquiries = getEnquiries().map((item, index) => ({ ...item, __index: index })).filter(e => {
    const content = [firstValue(e, ["name", "fullName", "citizenName"], ""), firstValue(e, ["email", "emailAddress"], ""), firstValue(e, ["message", "subject", "enquiry", "description"], "")].join(" ").toLowerCase();
    return content.includes(search);
  });
  $("#enquiry-list").innerHTML = enquiries.slice().reverse().map(e => {
    const name = firstValue(e, ["name", "fullName", "citizenName"], "Citizen");
    const email = firstValue(e, ["email", "emailAddress"], "");
    const message = firstValue(e, ["message", "subject", "enquiry", "description"], "No message provided.");
    const subject = firstValue(e, ["subject"], "");
    return `<article class="enquiry-card"><div class="enquiry-top"><div><h3>${escapeHTML(name)}</h3>${email && email !== "—" ? `<a href="mailto:${escapeHTML(email)}">${escapeHTML(email)}</a>` : ""}</div><button class="delete-btn" data-delete-enquiry="${e.__index}">Delete</button></div>${subject && subject !== message ? `<p><strong>${escapeHTML(subject)}</strong></p>` : ""}<p>${escapeHTML(message)}</p><time>${escapeHTML(getDate(e))}</time></article>`;
  }).join("");
  $("#enquiries-empty").classList.toggle("hidden", enquiries.length > 0);
}

$("#login-form").addEventListener("submit", event => {
  event.preventDefault();
  const username = $("#username").value.trim();
  const password = $("#password").value;
  if (username === "admin" && password === "admin123") {
    sessionStorage.setItem(LOGIN_KEY, "true");
    $("#login-error").textContent = "";
    openApp();
  } else {
    $("#login-error").textContent = "Incorrect username or password. Try the demo credentials shown below.";
  }
});
$("#logout-btn").addEventListener("click", () => {
  sessionStorage.removeItem(LOGIN_KEY);
  $("#admin-app").classList.add("hidden");
  $("#login-screen").classList.remove("hidden");
  $("#password").value = "";
});
document.addEventListener("click", event => {
  const pageButton = event.target.closest("[data-page]");
  if (pageButton) {
    event.preventDefault();
    showPage(pageButton.dataset.page);
  }
  const deleteService = event.target.closest("[data-delete-service]");
  if (deleteService) {
    const index = Number(deleteService.dataset.deleteService);
    const services = getServices();
    const service = services[index];
    if (service && confirm(`Delete "${service.name}"?`)) {
      services.splice(index, 1);
      writeStore(SERVICES_KEY, services);
      renderServices();
    }
  }
  const deleteEnquiry = event.target.closest("[data-delete-enquiry]");
  if (deleteEnquiry) {
    const index = Number(deleteEnquiry.dataset.deleteEnquiry);
    const enquiries = getEnquiries();
    if (confirm("Delete this enquiry?")) {
      enquiries.splice(index, 1);
      writeStore(ENQUIRIES_KEY, enquiries);
      renderEnquiries();
      renderDashboard();
    }
  }
});
$("#complaints-table").addEventListener("change", event => {
  const select = event.target.closest("[data-complaint-index]");
  if (!select) return;
  const index = Number(select.dataset.complaintIndex);
  const complaints = getComplaints();
  if (!complaints[index]) return;
  complaints[index].status = select.value;
  writeStore(COMPLAINTS_KEY, complaints);
  renderComplaints();
  renderDashboard();
});
$("#service-form").addEventListener("submit", event => {
  event.preventDefault();
  const services = getServices();
  services.push({
    id: `service-${Date.now()}`,
    name: $("#service-name").value.trim(),
    category: $("#service-category").value,
    description: $("#service-description").value.trim()
  });
  writeStore(SERVICES_KEY, services);
  event.target.reset();
  $("#service-feedback").textContent = "Service added successfully.";
  renderServices();
  setTimeout(() => { $("#service-feedback").textContent = ""; }, 2500);
});
$("#complaint-search").addEventListener("input", renderComplaints);
$("#complaint-filter").addEventListener("change", renderComplaints);
$("#enquiry-search").addEventListener("input", renderEnquiries);
$("#refresh-complaints").addEventListener("click", () => { renderComplaints(); renderDashboard(); });
$("#refresh-enquiries").addEventListener("click", () => { renderEnquiries(); renderDashboard(); });
window.addEventListener("storage", event => {
  if ([COMPLAINTS_KEY, ENQUIRIES_KEY, SERVICES_KEY].includes(event.key)) {
    renderDashboard();
    renderComplaints();
    renderServices();
    renderEnquiries();
  }
});

if (sessionStorage.getItem(LOGIN_KEY) === "true") openApp();
