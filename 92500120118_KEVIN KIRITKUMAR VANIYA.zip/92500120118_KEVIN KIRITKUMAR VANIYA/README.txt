SMARTCITY CONNECT — CLIENT + ADMIN PROJECT

FILES
- index.html / client.css: Citizen portal
- admin.html / admin.css / admin.js: Admin dashboard

HOW TO RUN
1. Extract the ZIP folder.
2. Keep all five files in the same folder.
3. Open the folder in VS Code and start a local server (for example, Live Server).
4. Open index.html and admin.html through the same server address and port, in the same browser profile. This is important so both pages share localStorage.
5. Demo admin login:
   Username: admin
   Password: admin123

COMPLAINT PHOTO UPLOAD
- Citizens can attach JPG, PNG or WEBP images up to 5 MB.
- The browser resizes/compresses the photo before saving it.
- Admin dashboard shows a thumbnail and a link to open the photo.
- Complaint records and photos are saved in localStorage.

IMPORTANT
- This is a front-end college project demonstration.
- localStorage is browser-specific and is not shared between different devices/users.
- Open both pages from the same folder/origin in the same browser profile so they use the same localStorage.
- Demo login is not secure authentication.
- Website gallery photos load from Unsplash and therefore require an internet connection.
- For a real deployment, use a backend, database, secure authentication and server-side image storage.
